// statusHandler.js
module.exports = async (zk, mek, config) => {
  if (mek.key && mek.key.remoteJid === 'status@broadcast') {
    if (config.AUTO_STATUS_SEEN === "true") {
      await zk.readMessages([mek.key]);
    }

    if (config.AUTO_STATUS_REPLY === "true") {
      const user = mek.key.participant;
      const text = `${config.AUTO_STATUS__MSG}`;
      await zk.sendMessage(user, { text: text, react: { text: '💜', key: mek.key } }, { quoted: mek });
    }
  }
};
