// messageRead.js
module.exports = async (zk, mek, config) => {
  if (config.READ_MESSAGE === 'true') {
    await zk.readMessages([mek.key]);  // Mark message as read
    console.log(`Marked message from ${mek.key.remoteJid} as read.`);
  }
};
