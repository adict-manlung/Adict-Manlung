const fs = require('fs');
const path = require('path');

const getEmojisFromFile = (filename) => {
  const filePath = path.join(__dirname, 'database', `${filename}.json`);
  try {
    const data = fs.readFileSync(filePath, 'utf8');
    const parsedData = JSON.parse(data);
    return parsedData.emojis || [];
  } catch (error) {
    console.error(`Error reading or parsing ${filename}: ${error.message}`);
    return [];
  }
};

module.exports = (m, senderNumber, botNumber, conf, isReact) => {
  const autoReactEmojis = getEmojisFromFile('autoReactEmojis');  // Default emojis for auto-react
  const heartReactEmojis = getEmojisFromFile('heartEmojis');      // Emojis for heart react
  const ownerEmojis = getEmojisFromFile('ownerEmojis');           // Emojis for owner react

  // Auto react for non-bot messages (sender is not the bot)
  if (!isReact && senderNumber !== botNumber) {
    if (conf.AUTO_REACT === 'yes' && autoReactEmojis.length > 0) {
      const randomReaction = autoReactEmojis[Math.floor(Math.random() * autoReactEmojis.length)];
      m.react(randomReaction);
    }
  }

  // Owner react (when sender is the bot)
  if (!isReact && senderNumber === botNumber && conf.OWNER_REACT === 'yes' && ownerEmojis.length > 0) {
    const randomOwnerReaction = ownerEmojis[Math.floor(Math.random() * ownerEmojis.length)];
    m.react(randomOwnerReaction);
  }

  // Heart react for non-bot messages (sender is not the bot)
  if (!isReact && senderNumber !== botNumber && conf.HEART_REACT === 'yes' && heartReactEmojis.length > 0) {
    const randomHeartReaction = heartReactEmojis[Math.floor(Math.random() * heartReactEmojis.length)];
    m.react(randomHeartReaction);
  }

  // Heart react for bot (if the bot itself sends the message)
  if (!isReact && senderNumber === botNumber && conf.HEART_REACT === 'yes' && heartReactEmojis.length > 0) {
    const randomHeartReaction = heartReactEmojis[Math.floor(Math.random() * heartReactEmojis.length)];
    m.react(randomHeartReaction);
  }
};
